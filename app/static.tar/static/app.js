// === State ===
let ws = null;
let detectEnabled = true;
let latestFeatures = null;
let latestIndices  = null;

// === UI helpers ===
const $ = (id) => document.getElementById(id);
function setLlmStatus(text, cls){
  const el = $('llmStatus');
  if(!el) return;
  el.textContent = text || '';
  el.classList.remove('running','ok','err');
  if(cls) el.classList.add(cls);
}
function fmt(v, digits=2){
  if(v===undefined || v===null || Number.isNaN(v)) return '—';
  return (typeof v==='number')? v.toFixed(digits) : String(v);
}

// === WebSocket ===
function openWS(){
  ws = new WebSocket(`ws://${location.host}/ws`);
  ws.onopen = () => { console.log('WS open'); };
  ws.onclose = () => { console.log('WS closed'); setTimeout(openWS, 1500); };
  ws.onerror = (e) => { console.warn('WS err', e); };

  ws.onmessage = (ev) => {
    try {
      const msg = JSON.parse(ev.data);
      // preview
      if (msg.frame_b64) $('preview').src = `data:image/jpeg;base64,${msg.frame_b64}`;
      // fps, quality
      $('fps').textContent    = `FPS: ${fmt(msg.fps,1)}`;
      const q = msg.quality || {};
      $('quality').textContent= `품질(조도:${fmt(q.lighting)}, fps:${fmt(q.fps)}, 가림:${fmt(q.occlusion)})`;

      // features / indices
      latestFeatures = msg.features || {};
      latestIndices  = msg.indices  || {};

      $('m_perclos').textContent = fmt(latestFeatures.perclos,2);
      $('m_yawn').textContent    = fmt(latestFeatures.yawn_rate_min,2);
      $('m_posture').textContent = fmt(latestFeatures.posture_angle_norm,2);
      $('m_hpvar').textContent   = fmt(latestFeatures.headpose_var,2);
      $('m_gaze').textContent    = fmt(latestFeatures.gaze_on_pct,2);
      $('m_near').textContent    = fmt(latestFeatures.near_work,2);

      $('idx_fatigue').textContent = fmt(latestIndices.fatigue,1);
      $('idx_stress').textContent  = fmt(latestIndices.stress,1);

      const evs = msg.events || {};
      $('e_blink').textContent = String(evs.blink ?? 0);
      $('e_yawn').textContent  = String(evs.yawn ?? 0);
      $('e_nod').textContent   = String(evs.nodding ?? 0);

      // 버튼 라벨 동기화
      detectEnabled = !!msg.detect_enabled;
      $('btnToggleDetect').textContent = `감지: ${detectEnabled?'ON':'OFF'}`;
      $('btnToggleDetect').classList.toggle('primary', detectEnabled);
    } catch(e){
      console.warn('WS parse fail', e);
    }
  };
}

// === Actions ===
function toggleDetect(){
  detectEnabled = !detectEnabled;
  $('btnToggleDetect').textContent = `감지: ${detectEnabled?'ON':'OFF'}`;
  $('btnToggleDetect').classList.toggle('primary', detectEnabled);
  try {
    ws && ws.readyState===1 && ws.send(JSON.stringify({cmd:'detect', enable: detectEnabled}));
  } catch(_){}
}

// LLM Report request with status UI
async function requestReport(){
  const btn = $('btnReport');
  try{
    btn.disabled = true;
    setLlmStatus('LLM 보고서 생성 중…', 'running');

    // 기본 값 보정
    const stats = {
      avg_fatigue: (latestIndices?.fatigue ?? 0)*1.0,
      avg_stress:  (latestIndices?.stress  ?? 0)*1.0,
      perclos:     (latestFeatures?.perclos ?? 0)
    };
    const docs = [{ title: '세션 로그', path: 'local' }];

    const res = await fetch('/report', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({stats, docs})
    });
    if(!res.ok){
      const msg = `요청 실패 (${res.status})`;
      setLlmStatus(msg,'err');
      throw new Error(msg);
    }
    const data = await res.json();
    const srcLabel = data.source==='local' ? 'EXAONE' : 'Fallback';
    setLlmStatus(`완료 (${srcLabel})`,'ok');
    $('reportBox').value = data.text || '';
  }catch(err){
    console.error(err);
    setLlmStatus('실패: '+(err?.message||'unknown'),'err');
  }finally{
    btn.disabled = false;
  }
}

// LLM Health check → 상태 표시 (GPU 로드 확인에 도움)
async function checkHealth(){
  try{
    setLlmStatus('헬스 체크 중…','running');
    const res = await fetch('/llm/health');
    const data = await res.json();
    const src = data.used_fallback ? 'Fallback' : 'EXAONE';
    const dbg = data.exaone || {};
    const deviceInfo =
      `loaded=${dbg.loaded} device=${dbg.device_map||'?'} cuda=${dbg.cuda_available} name=${dbg.cuda_name||'-'}`;
    setLlmStatus(`헬스 OK (${src}) • ${deviceInfo}`,'ok');
  }catch(e){
    console.error(e);
    setLlmStatus('헬스 실패','err');
  }
}

// === Bindings ===
function bind(){
  $('btnToggleDetect').addEventListener('click', toggleDetect);
  $('btnReport').addEventListener('click', requestReport);
  $('btnHealth').addEventListener('click', checkHealth);
}
document.addEventListener('DOMContentLoaded', () => { bind(); openWS(); });
